/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include "bmp280.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
#define MAX_SAMPLES 2000
float historial_altitud[MAX_SAMPLES];
uint32_t historial_tiempo[MAX_SAMPLES];
uint32_t sample_count = 0;
bool grabando = false;
bool prueba_finalizada = false;

BMP280_HandleTypedef bmp280;
float temperatura, presion_Pa, humedad, altitud_m;
float P0 = 101325.0f;

float h_est = 0, v_est = 0;
uint32_t tiempo_anterior = 0;
int rechazos_consecutivos = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
// Redirección de printf
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

PUTCHAR_PROTOTYPE
{
  HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
  return ch;
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
    ssd1306_Init();
    ssd1306_Fill(Black);
    ssd1306_SetCursor(2, 10);
    ssd1306_WriteString("ESTABILIZANDO...", Font_7x10, White);
    ssd1306_UpdateScreen();

    // Inicializar BMP280
    bmp280.i2c = &hi2c1;
    bmp280.addr = BMP280_I2C_ADDRESS_0;
    bmp280_params_t params;
    bmp280_init_default_params(&params);
    bmp280_init(&bmp280, &params);

    // ESPERA CRÍTICA: Damos 2 segundos para que el sensor se asiente
    HAL_Delay(2000);

    // Calibrar P0 con promedio de 30 muestras
    float suma_p = 0;
    for(int i=0; i<30; i++) {
        bmp280_read_float(&bmp280, &temperatura, &presion_Pa, &humedad);
        suma_p += presion_Pa;

        // Feedback visual para saber que no se colgó
        if(i % 10 == 0) {
            ssd1306_WriteString(".", Font_7x10, White);
            ssd1306_UpdateScreen();
        }
        HAL_Delay(100);
    }
    P0 = suma_p / 30.0f;

    ssd1306_Fill(Black);
    ssd1306_SetCursor(2, 10);
    ssd1306_WriteString("CERO FIJADO", Font_7x10, White);
    ssd1306_UpdateScreen();
    HAL_Delay(500);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
      while (1)
      {
        // --- 1. CONTROL DE TIEMPO PARA EL FILTRO ---
        uint32_t tiempo_actual = HAL_GetTick();
        float delta_t = (tiempo_actual - tiempo_anterior) / 1000.0f;

        // Solo procesamos si ha pasado el tiempo suficiente y la prueba no ha terminado
        if (delta_t >= 0.05f && !prueba_finalizada) {
            tiempo_anterior = tiempo_actual;

            // --- 2. LEER SENSOR Y FILTRAR ---
            if (bmp280_read_float(&bmp280, &temperatura, &presion_Pa, &humedad)) {
                float altitud_cruda = 44330.0f * (1.0f - pow((presion_Pa / P0), 0.1902949f));

                // Filtro Alpha-Beta
                float v_bruta = (altitud_cruda - h_est) / delta_t;

                // Rechazo de Outliers (Velocidad menor a Mach 1)
                if ((v_bruta > -343.0f && v_bruta < 343.0f) || rechazos_consecutivos > 40) {
                    rechazos_consecutivos = 0;

                    float alpha_val = 0.45f;
                    float beta_val = 0.05f;

                    float h_pred = h_est + (v_est * delta_t);
                    float error = altitud_cruda - h_pred;

                    h_est = h_pred + (alpha_val * error);
                    v_est = v_est + ((beta_val / delta_t) * error);
                } else {
                    rechazos_consecutivos++;
                    h_est = h_est + (v_est * delta_t);
                }
            }

            // --- 3. LÓGICA DE GRABACIÓN ---
            if (!grabando && h_est > 1.0f) {
                grabando = true;
            }

            if (grabando) {
                if (sample_count < MAX_SAMPLES) {
                    historial_altitud[sample_count] = h_est;
                    historial_tiempo[sample_count] = tiempo_actual;
                    sample_count++;
                } else {
                    grabando = false;
                    prueba_finalizada = true;
                }
            }

            // --- 4. ACTUALIZAR OLED (MODO VIVO) ---
            ssd1306_Fill(Black);
            char buffer[32];
            sprintf(buffer, "Alt: %.2fm", h_est);
            ssd1306_SetCursor(2, 5);
            ssd1306_WriteString(buffer, Font_7x10, White);

            if (grabando) {
                sprintf(buffer, "REC: %lu/%d", sample_count, MAX_SAMPLES);
                ssd1306_SetCursor(2, 25);
                ssd1306_WriteString(buffer, Font_7x10, White);
            }
            ssd1306_UpdateScreen();
        }

        // --- 5. MODO DESCARGA (SOLO CUANDO TERMINA) ---
        if (prueba_finalizada) {
            ssd1306_Fill(Black);
            ssd1306_SetCursor(2, 5);
            ssd1306_WriteString("FIN - COMPLETO", Font_7x10, White);
            ssd1306_SetCursor(2, 25);
            ssd1306_WriteString("PRESIONE 'S' PC", Font_7x10, White);
            ssd1306_UpdateScreen();

            uint8_t tecla_recibida = 0;
            // Esperamos a que el usuario presione 'S' en PuTTY
            if (HAL_UART_Receive(&huart1, &tecla_recibida, 1, 10) == HAL_OK) {
                if (tecla_recibida == 's' || tecla_recibida == 'S') {
                    printf("\r\n--- INICIO DESCARGA ---\r\n");
                    printf("TIEMPO(ms),ALTITUD(m)\r\n");

                    for (uint32_t i = 0; i < sample_count; i++) {
                        printf("%lu,%.2f\r\n", i * 50, historial_altitud[i]);
                        HAL_Delay(1); // Pequeña pausa para no saturar el PC
                    }
                    printf("--- FIN DESCARGA ---\r\n");
                }
            }
        }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
      }
}
  /* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
